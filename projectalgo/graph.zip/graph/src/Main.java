import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import java.util.TreeMap;

public class Main {
    static Vertex minDistance(HashMap<Vertex,Integer> dist, ArrayList<Vertex> sptSet)
    {
        int min = Integer.MAX_VALUE;
        Vertex minVertex = null;
        for (int v = 0; v < sptSet.size(); v++)
            if (dist.get(sptSet.get(v)) <= min) {
                min = dist.get(sptSet.get(v));
                minVertex = sptSet.get(v);
            }

        return minVertex;
    }

    static void printSolution(HashMap<Vertex,Integer> dist)
    {
        System.out.println("Vertex   Distance from Source");
        for(Vertex v : dist.keySet())
        {
            System.out.println(v.name + " " + dist.get(v));
        }
    }


    static void dijkstra(ArrayList<Vertex> graph, Vertex src,int V)
    {
        HashMap<Vertex,Integer> dist = new HashMap<>();
        ArrayList<Vertex> sptSet = new ArrayList<>();
        for (int i = 0; i < V; i++) {
            if(graph.get(i) != src)
                dist.put(graph.get(i),Integer.MAX_VALUE);
            else
                dist.put(src,0);
        }


        for (int count = 0; count < V - 1; count++) {

            Vertex u = minDistance(dist, sptSet);

            // Mark the picked vertex as processed
            sptSet.add(u);

            // picked vertex.
            for(int v = 0; v < u.edges.size();v++)
                if (sptSet.indexOf(u.edges.get(v).endVertex) != -1 &&
                        dist.get(u) != Integer.MAX_VALUE &&
                        dist.get(u) + u.edges.get(v).weight < dist.get(v))
                            dist.put(u.edges.get(v).endVertex,dist.get(u) + u.edges.get(v).weight) ;
         /*   for (int v = 0; v < V; v++)

                if (!sptSet[v] && graph[u][v] != 0 &&
                        dist[u] != Integer.MAX_VALUE && dist[u] + graph[u][v] < dist[v])
                    dist[v] = dist[u] + graph[u][v];*/

        }

        // print the constructed distance array
    //    printSolution(dist);
    }
    public static void main(String[] args)
    {
        System.out.println("Enter n");
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        ArrayList<Vertex> graph = new ArrayList<>();
        for(int i = 0;i < n;i++) {
            graph.add(new Vertex(String.valueOf(i)));
        }
        System.out.println("Enter edges");
        int m = in.nextInt();
        for(int i = 0;i < m;i++)
        {
           // System.out.println("Enter start, end , weight");
            int x , y , z;
            x = in.nextInt();
            y = in.nextInt();
            z = in.nextInt();
            Edge e = new Edge(graph.get(x),graph.get(y),z);
            graph.get(x).edges.add(e);
            graph.get(y).edges.add(e);
        }
        dijkstra(graph,graph.get(0),n);

    }
}
